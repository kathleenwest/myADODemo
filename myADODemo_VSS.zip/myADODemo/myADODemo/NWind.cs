﻿namespace myADODemo
{


    partial class NWind
    {
    }
}
